public class Poolarea {
    Alarmunit alarmconnection = new Alarmunit();

    public void TriggerMotionAlarm() {
        alarmconnection.startMotionAlarm("Poolarea");
    }
}
