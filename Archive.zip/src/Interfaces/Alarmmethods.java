package Interfaces;

public interface Alarmmethods {

    public void triggerSmokeAlarm(String area);

    public void triggerBurgluryAlarm(String area);

}
