public class Livingroom extends Room{

    Alarmunit alarmconnection = new Alarmunit();
    public Livingroom(int windows, int doors, String area) {
        super(windows, doors, area);
    }
    public void TriggerMotionAlarm() {
        alarmconnection.startMotionAlarm("Livingroom");
    }
}
