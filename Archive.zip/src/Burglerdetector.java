public class Burglerdetector {

    Alarmunit alarmconnection = new Alarmunit();

    public void TriggerBurglerAlarm(String area) {
        alarmconnection.startBurgluryAlarm(area);
    }

}
