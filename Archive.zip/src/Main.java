import java.util.ArrayList;
import java.util.Scanner;
import java.lang.Math;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Alarmunit alarmunit = new Alarmunit();

        Room room1 = new Room(2, 1, "Bedroom 1");
        Room room2 = new Room(1, 1, "Bedroom 2");
        Room room3 = new Room(1, 1, "Bedroom 3");
        Room room4 = new Room(2, 1, "Bedroom 4");
        Room room5 = new Room(1, 1, "Bedroom 5");
        ArrayList<Room> rooms = new ArrayList<Room>();
        rooms.add(room1);
        rooms.add(room2);
        rooms.add(room3);
        rooms.add(room4);
        rooms.add(room5);

        Poolarea pool = new Poolarea();
        Kitchen kitchen = new Kitchen(1, 1, "Kitchen");
        Livingroom livingroom = new Livingroom(2, 1, "Livingroom");
        Hallway hallway = new Hallway(0, 1, "Hallway");

        int input;

        while (true) {
            System.out.println("(0) Activate system (1) Deactivate system (2) fire simulation (3) movement simulation (4) Burglary simulation (5) turn off alarm");
            input = scanner.nextInt();

            switch (input) {
                case 0:
                    // Calling method to activate the alarmsystem
                    Alarmunit.setAlarmStatus(true);
                    break;
                case 1:
                    // Calling method to deactivate the alarmsystem
                    Alarmunit.setAlarmStatus(false);
                    break;
                case 2:
                    // Calling method to simulate fire
                    System.out.println("Which area is on fire: (1) Livingroom (2) Kitchen (3) Hallway (4) one of the bedrooms");
                    input = scanner.nextInt();

                    switch (input) {
                        case 1:
                            livingroom.triggerSmokeAlarm(livingroom.getArea());
                            break;
                        case 2:
                            kitchen.triggerSmokeAlarm(kitchen.getArea());
                            break;
                        case 3:
                            hallway.triggerSmokeAlarm(hallway.getArea());

                            break;
                        case 4:
                            int randomNumber = (int) (Math.random() * 5);
                            rooms.get(randomNumber).triggerSmokeAlarm("Room " + randomNumber);
                            break;
                    }
                    break;
                case 3:
                    System.out.println("In which area is the movement: (1) Livingroom (2) Poolarea (3) Hallway");
                    input = scanner.nextInt();
                switch (input) {
                    case 1:
                        livingroom.TriggerMotionAlarm();
                        break;
                    case 2:
                        pool.TriggerMotionAlarm();
                        break;
                    case 3:
                        hallway.TriggerMotionAlarm();
                        break;
                }
                    break;
                case 4:
                    System.out.println("In which area is the window(s) or doors breached: (1) Livingroom (2) Kitchen (3) Hallway (4) one of the bedrooms");
                    input = scanner.nextInt();
                    switch (input) {
                        case 1:
                            livingroom.triggerBurgluryAlarm(livingroom.getArea());
                            break;
                        case 2:
                            kitchen.triggerBurgluryAlarm(kitchen.getArea());
                            break;
                        case 3:
                            hallway.triggerBurgluryAlarm(hallway.getArea());
                            break;
                        case 4:
                            int randomNumber = (int) (Math.random() * 5);
                            rooms.get(randomNumber).triggerBurgluryAlarm("Room " + randomNumber);
                            break;
                    }
                    break;
                case 5:
                    System.out.println("You have deactivated the alarm");
                    Alarmunit.setAlarmStatus(false);
                    break;

            }
        }
    }
}
