public class Kitchen extends Room{
    Alarmunit alarmconnection = new Alarmunit();
    public Kitchen(int windows, int doors, String area) {
        super(windows, doors, area);
    }
    public void TriggerMotionAlarm() {
        alarmconnection.startMotionAlarm("Kitchen");
    }
}
