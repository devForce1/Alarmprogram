import java.lang.Thread;

public class Alarmunit {

    public static boolean alarmStatus;

    public Alarmunit() {

    }

    public void startSmokeAlarm(String location) {
        if (isAlarmStatus()) {
            for (int i = 0; i < 3; i++) {
                System.out.println("Smoke has been detected in " + location + " ALARM ALARM ALARM");
                try {
                    Thread.sleep(1500);
                } catch (Exception e) {
                }
            }
            System.out.println("Press 5 to deactivate the alarm");
        } else {
            System.out.println("System is Off-Line");
        }
    }


    public void startMotionAlarm(String location) {
        if (isAlarmStatus()) {
            for (int i = 0; i < 3; i++) {
                System.out.println("Suspicious movement has been detected in " + location + " ALARM ALARM ALARM");
                try {
                    Thread.sleep(1500);
                } catch (Exception e) {
                }
            }
            System.out.println("Press 5 to deactivate the alarm");
        } else {
            System.out.println("System is Off-Line");
        }
    }


    public void startBurgluryAlarm(String location) {
        if (isAlarmStatus()) {
            for (int i = 0; i < 3; i++) {
                System.out.println("Possible bulglary attempt has been detected in " + location + " ALARM ALARM ALARM");
                try {
                    Thread.sleep(1500);
                } catch (Exception e) {
                }
            }
            System.out.println("Press 5 to deactivate the alarm");
        } else {
            System.out.println("Sytem is Off-Line");
        }
    }

    public void activateSprinklers() {
        if (isAlarmStatus()) {
            System.out.println("**Sprinkler is activated**");
        }
    }
    public static boolean isAlarmStatus() {
        return alarmStatus;
    }

    public static void setAlarmStatus(boolean alarmStatus) {
        Alarmunit.alarmStatus = alarmStatus;
        if(isAlarmStatus()) {
            System.out.println("System is now On-Line");
        }
        else if(!isAlarmStatus()) {
            System.out.println("System is now Off-Line");
        }
    }
}


