public class Motiondetector {
    Alarmunit alarmconnection = new Alarmunit();

    public void TriggerMotionAlarm(String area) {
        alarmconnection.startMotionAlarm(area);
    }
}
