public class Smokedetector {
    Alarmunit alarmconnection = new Alarmunit();

    public void TriggerSmokeAlarm(String area) {
        alarmconnection.startSmokeAlarm(area);
    }
}
