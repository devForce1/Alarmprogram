public class Sprinkler {

    Alarmunit alarmconnection = new Alarmunit();
    public void activateSprinkler() {
        alarmconnection.activateSprinklers();
    }
}
