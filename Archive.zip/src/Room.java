import Interfaces.Alarmmethods;

public class Room implements Alarmmethods {

    private int windows;
    private int doors;
    private String area;

    Smokedetector smokeDetector = new Smokedetector();
    Burglerdetector burgelruDetector = new Burglerdetector();

    Sprinkler sprinkler = new Sprinkler();

    /*public Room() {

    }*/

    public Room(int windows, int doors, String area) {
        this.windows = windows;
        this.doors = doors;
        this.area = area;
    }

    @Override
    public void triggerSmokeAlarm(String area) {
        sprinkler.activateSprinkler();
        smokeDetector.TriggerSmokeAlarm(this.area);
    }
    @Override
    public void triggerBurgluryAlarm(String area) {
        burgelruDetector.TriggerBurglerAlarm(this.area);
    }

    public int getWindows() {
        return windows;
    }

    public void setWindows(int windows) {
        this.windows = windows;
    }

    public int getDoors() {
        return doors;
    }

    public void setDoors(int doors) {
        this.doors = doors;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
